<?php

class DataBase
	{
		private string $host     = 'localhost';
		private string $user 	 = 'root';
		private string $password = 'root';
		private string $dataBase;
		private $link;
		
		/**
		 * 
		 */
		public function __construct($__dataBase)
		{
			//name of database
			$this->dataBase	= $__dataBase;

			//connect to database
			$this->link = mysqli_connect($this->host, $this->user, $this->password, $this->dataBase);
		}

		/**
		 * 
		 */
		public function selectFromTable(string $__table, string $__id)
		{	
			$query 	= $this->createSelectById($__table, $__id);
			$result = $this->makeQuery($query);					
		
			if(!$result) {
				return 'bad query:(';
			}
			return $result->fetch_assoc(); 
		}

		/**
		 * 
		 */
		public function insertIntoTable(string $__table, array $__data)
		{
			$query  = $this->createInsert($__table, $__data);
			$result = $this->makeQuery($query);
			return $result;
		}

		/**
		 * 
		 */
		public function deleteFromTable(string $__table, string $__id)
		{
			$query  = $this->createDeleteById($__table, $__id);
			$result = $this->makeQuery($query);
			return $result;
		}

		/**
		 * 
		 */
		private function createSelectById(string $__table, string $__id)
		{
			return "SELECT * FROM $__table WHERE id=$__id";
		}

		/**
		 *
		 */
		private function createDeleteById(string $__table, string $__id)
		{
			return "DELETE FROM $__table WHERE id=$__id";
		}

		/**
		 * 
		 */
		private function createInsert(string $__table, array $__data)
		{
			$fieldsQuery = $valuesQuery = '';
			foreach($__data as $field => $value) {
				$fieldsQuery .= "`$field`,";
				$valuesQuery .= "'$value',";
			}

			$fieldsQuery = substr($fieldsQuery, 0, -1);
			$valuesQuery = substr($valuesQuery, 0, -1);
			return "INSERT INTO `$__table` ($fieldsQuery) VALUES ($valuesQuery)";
		}

		/**
		 * 
		 */
		private function makeQuery(string $__query)
		{
			$result = mysqli_query($this->link, $__query);
			return $result;
		}
		


	}