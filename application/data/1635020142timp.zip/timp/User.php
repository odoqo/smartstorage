<?php 

require_once "DataBase.php";

class User 
{
    private string   $userName;
    private int   $role;
    private DataBase $dataBase;
    private string $position;

    /**
     * 
     */
    public function __construct(string $__login, string $__role)
    {
        $this->userName = $__login;
        $this->role     = $__role;
        $this->position     = $__login;
        $this->dataBase = new DataBase('timp');
    }
    
        /**
     * 
     */
    public function changePosition(string $newPosition)
    {
        $this->position = $newPosition;
    }
    
    /**
     * 
     */
    public function getPosition()
    {
        return $this->position;
    }
    
        public function getName()
    {
        return $this->userName;
    }

    /**
     * 
     */
    public function uploadFile(string $__virtualPath, array $__upload)
    {

        /**
         * Code authorization
         */

        $tmpName = $__upload['tmp_name']; 
        $name    = $__upload['name'];
        $path    = 'FILES/'. time() . $name;
    
        if(!move_uploaded_file($tmpName, $path)) {
            return 'error: upload file';
        }

        $data = array(
            'name'         => $name,
            'path'         => $path,
            'virtual_path' => $__virtualPath . $name,
            'owner'        => $this->userName,
        );
        
        $result = $this->dataBase->insertIntoTable('files', $data);
        
        if (!$result) {
            return 'error: dataBase';
        }

        return 1;
    }

    /**
     * 
     */
    public function downloadFile(string $__id) 
    {

        /**
         * Code authorization
         */
        
        $path = $this->dataBase->selectFromTable('files', $__id)['path'];

        if (file_exists($path)) {
            
            if (ob_get_level()) {
                ob_end_clean();
            }

            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename=' . basename($path));
            header('Content-Transfer-Encoding: binary');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($path));
            
            readfile($path);
        }
    }

    /**
     * 
     */
    public function newCatalog(string $__name, string $__virtualPath)
    {
        $data = array(
            'name'         => $__name,
            'owner'        => $this->userName,
            'virtual_path' => $__virtualPath
        );

        $this->dataBase->insertIntoTable('cataloges', $data);
    }

    /**
     * 
     */
    public function deleteFile(string $__id) 
    {
        /**
         * Code authorization
         * 
         */

        $file = $this->dataBase->selectFromTable('files', $__id);
        
        $this->dataBase->deleteFromTable('files', $__id);
        
        $path = $file['path'];
        unlink($path);
    }

    /**
     * 
     */
    public function deleteCatalog(string $__id)
    {
        /**
         * Code authorization
         */

        //$catalog = $this->dataBase->selectFromTable('cataloges', $__id);
        
        $this->dataBase->deleteFromTable('cataloges', $__id);
    }
}
