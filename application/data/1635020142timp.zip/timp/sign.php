<?php
session_start();

//подключение файлов
require_once 'Template.php';
require_once 'vendor\connect.php';
$template  = file_get_contents('sign.html');
$resultArr = array();

/**
 * Функция генерирует случайную строку.
 *
 * @param integer $__length Число для проверки.
 *
 * @return string
 */
function generateCode(int $__length=6)
{
    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHI JKLMNOPRQSTUVWXYZ0123456789";
    $code  = "";
    $lenth = strlen($chars) - 1;  
    
    //
    while (strlen($code) < $__length) {
        $code .= $chars[mt_rand(0, $lenth)];  
    }
    
    //
    return $code;
}

//Для сообщения об ошибке
if (isset($_SESSION['mess'])) {
    $resultArr['errorAuth'] = $_SESSION['mess'];
    unset($_SESSION['mess']);
}

//
class Profile {
    private $_login;
    private $_password;
    
    /**
    * Конструктор.
    *
    * @param string $__login    Логин.
    * @param string $__password Пароль.
    *
    * @return string
    */
    function __construct(string $__login, string $__password)
    {
        $this->_login    = $__login;
        $this->_password = $__password;
    }
    
    /**
    * Авторизация.
    *
    * @return string
    */
    public function auth()
    {    
        $connect   = mysqli_connect('localhost', 'root', 'root', 'timp');
        $checkUser = mysqli_query($connect, "SELECT * FROM `users` WHERE `login`='$this->_login' AND `pass`='$this->_password'"); 
         
        //если нашли в базе
        if (mysqli_num_rows($checkUser) > 0) {
            $user = mysqli_fetch_assoc($checkUser);            
            $hash = md5(generateCode(10));
            
            //устанавливаем куки
            mysqli_query($connect, "UPDATE users SET hash='".$hash."' WHERE login='".$this->_login."'");
            setcookie('login', $this->_login, time() + 100);
            setcookie('hash', $hash, time() + 100);
            return true;
        }
        else { //Логин или пароль не подошел
            $_SESSION['mess'] = 'Неправильное имя пользователя или пароль';
            return false; 
        }
    }
}

//проверка на наличие куки
if (isset($_COOKIE['login']) && isset($_COOKIE['hash'])) {  
    $query    = mysqli_query($connect, "SELECT * FROM `users` WHERE login = '".$_COOKIE['login']."'");
    $userData = mysqli_fetch_assoc($query);
    
    //для безопасности проверка куки
    if ($userData['hash'] == $_COOKIE['hash'] && $userData['login'] == $_COOKIE['login']) {
        header('Location: .\index.php');
    }
    else {
        print_r('Проверьте куки');
    }
}

//Авторизация
if (isset($_POST['login']) && isset($_POST['pass'])) {
    $profile = new Profile($_POST['login'], md5($_POST['pass']));
    if ($profile->auth()) {
        header('Location: .\index.php');
    } else {
         header('Location: .\sign.php');
    }
}

//вывод шаблона
print (Template::build($template, $resultArr));
