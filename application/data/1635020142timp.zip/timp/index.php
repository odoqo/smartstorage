<?php

require_once 'Template.php';
require_once 'User.php';
require_once 'vendor\connect.php';
$template  = file_get_contents('main.htm');
$resultArr = array();

//проверка на наличие куки
if (isset($_COOKIE['login']) && isset($_COOKIE['hash'])) {  
    $query    = mysqli_query($connect, "SELECT * FROM `users` WHERE login = '".$_COOKIE['login']."'");
    $userData = mysqli_fetch_assoc($query);
    
    //для безопасности проверка куки
    if (!($userData['hash'] == $_COOKIE['hash']) || !($userData['login'] == $_COOKIE['login'])) {
        header('Location: .\sign.php');
    }
}
 else {
     header('Location: .\sign.php');
}

$user = new User($userData['login'], $userData['isAdmin']);

/*$files = mysqli_query($connect, "SELECT * FROM `files` WHERE owner = '".$user->getName()."'");
$index=0;
while ($row = mysqli_fetch_array($files)) {
    $resultArr['data_cycle'][$index]['file_or_dir_name'] = $row[2];
    $index++;
}*/
$index=0;
$path = array_diff(scandir("memory/".$user->getPosition()), array('..', '.'));
foreach($path as $filename) {
    $resultArr['data_cycle'][$index]['file_or_dir_name'] = $filename;
        $index++;
}

//заполнение итогового массива
/*foreach ($characteristicsArr as $key => $value) {
    $resultArr['data_cycle'][$index3]['load_or_go'] = ($horseArr[$key] * $step)."-".(($horseArr[$key] + 1) * $step);
    $resultArr['data_cycle'][$index3]['id_file_or_cat'] = $colorArr[$key];
    $resultArr['data_cycle'][$index3]['name_1'] = $colorArr[$key];
    $index3++;
}*/

$resultArr['current_dir'] =$user->getPosition();


//вывод шаблона
print (Template::build($template, $resultArr));