<?php
session_start();

//подключение файлов
require_once 'Template.php';
$template  = file_get_contents('registration.html');
$resultArr = array();

//Для сообщения об ошибке
if (isset($_SESSION['mess'])) {
    $resultArr['errorAuth'] = $_SESSION['mess'];
    unset($_SESSION['mess']);
}

//вывод шаблона
print (Template::build($template, $resultArr));
