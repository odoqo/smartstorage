<?php

//
//print_r($_COOKIE);

/**
* Проверка на права доступа к файлу.
*
* @param string $__path Путь.
* @param string $__user Пользователь.
*
* @return string
*/
function authorization(string $__path, string $__user)
{
    //ищем строку с нужным файлом
    $data = file_get_contents('rightOfUsers/right.txt');
    preg_match('|'.$__path.'\[\|\|\|\][^\n]*|', $data, $matches);
    
    //обрезаем путь
    $position   = strpos($matches[0], '[|||]');
    $matches[0] = substr($matches[0], $position + 5);

    //проверка может ли пользователь исправлять файл
    if (preg_match('|'.$__user.'|', $matches[0])) {
        return true;
    }
    
    //
    return false;
}

//
print_r(authorization('gena@yandex.ru/123', 'dark@net.ua'));
